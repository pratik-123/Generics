
import UIKit

let arrayOfInt = [1,3,5,7]
let arrayOfString = ["iOS","Android"]

//Now you can print above array create 2 function like this

func printIntArray(forArrayOfInts arrayOfInt : [Int]){
    arrayOfInt.map({print($0)})
}
//and for string array print
func printStringArray(forArrayOfStrings arrayOfString: [String]){
    arrayOfString.map({print($0)})
}
///And call
printIntArray(forArrayOfInts: arrayOfInt)
printStringArray(forArrayOfStrings: arrayOfString)

//Now using generic function no need to create two function for print array

func printUsingGeneric<T>(forArray arrayOfValue : [T]){
    arrayOfValue.map({print($0)})
}

///And call is same like above
print("=========Call using Genric function========")
printUsingGeneric(forArray: arrayOfInt)
printUsingGeneric(forArray: arrayOfString)

/*
 Output:
 
 1
 3
 5
 7
 iOS
 Android
 =========Call using Genric function========
 1
 3
 5
 7
 iOS
 Android
 
 
 */










